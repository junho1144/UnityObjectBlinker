using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using System.Linq;
using UnityEngine.SceneManagement;
using UnityEngine.EventSystems;

public class BlinkManager : MonoBehaviour
{
    public static BlinkManager Instance { get; private set; }
    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(gameObject);

        SceneManager.sceneLoaded += OnSceneLoaded;

        FindAllSelectables();
    }



    bool filterOn;
    public bool FilterOn 
    { 
        get => filterOn; 
        set 
        {
            filterOn = value;

            if (filterOn)
            {
                FindAllSelectables();
            }
            else 
            {
                if (blinkingImages != null) 
                {
                    foreach (Image image in blinkingImages.ToList()) 
                    {
                        Color newImgColor = image.color;
                        newImgColor.a = 1f;

                        image.color = newImgColor;
                    }
                }
            }           
        } 
    }


    List<Image> blinkingImages = null;
    void OnSceneLoaded(Scene scene, LoadSceneMode mode)
    {
        if (FilterOn)
            FindAllSelectables();
    }



    void FindAllSelectables() 
    {
        blinkingImages = new List<Image>();

        // all selectables
        foreach (Canvas canvas in FindObjectsOfType<Canvas>()) 
        {
            blinkingImages.AddRange(
                canvas.GetComponentsInChildren<Selectable>(true)
                .Select(s => ImageOf(s))
                .Where(s => s != null));
        }

        // blink dynamic control - addMe
        foreach (BlinkDynamicControl blinkDynamic in FindObjectsOfType<BlinkDynamicControl>(true)) 
        {
            Image image = blinkDynamic.GetComponent<Image>();
            if (image != null) 
            {
                blinkingImages.Add(image);
            }
        }

        // delete ignoreMe
        blinkingImages = blinkingImages
            .Where(i => i.GetComponent<BlinkDynamicControl>() == null || !i.GetComponent<BlinkDynamicControl>().IgnoreMe)
            .ToList();
    }
    Image ImageOf(Selectable target) 
    {
        if (target is Button or Dropdown or InputField or Scrollbar)
        {
            return target.GetComponent<Image>();
        }
        else if (target is Toggle or Slider)
        {
            return target.GetComponentsInChildren<Image>(true).FirstOrDefault();
        }

        return null;
    }


    const float BlinkSpeed = 1f; // blink per sec
    const float BlinkIntensity = 0.9f; // changing alpha, MUST 0~1

    float nowAlphaRate = 1f;
    bool alphaRateGoUp = false;
    private void Update()
    {
        if (FilterOn)
        {
            float amount = Time.deltaTime * BlinkSpeed * BlinkIntensity * (alphaRateGoUp ? 2f : -2f);
            nowAlphaRate += amount;

            float minAlpha = Mathf.Clamp01(1f - BlinkIntensity);

            if (nowAlphaRate >= 1f)
            {
                alphaRateGoUp = false;
                nowAlphaRate = 1f;
            }
            if (nowAlphaRate <= minAlpha)
            {
                alphaRateGoUp = true;
                nowAlphaRate = minAlpha;
            }

            Image currentImage = null;
            Selectable current = EventSystem.current.currentSelectedGameObject?.GetComponent<Selectable>();
            if (current != null) 
            {
                currentImage = ImageOf(current);
            }
            foreach (Image image in blinkingImages)
            {
                if (currentImage == image)
                    continue;

                Color newImgColor = image.color;
                newImgColor.a = nowAlphaRate;

                image.color = newImgColor;
            }
        }
    }
}
