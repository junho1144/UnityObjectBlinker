using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlinkDynamicControl : MonoBehaviour
{
    [SerializeField] bool addMe;

    [SerializeField] bool ignoreMe;


    public bool AddMe => addMe;
    public bool IgnoreMe => ignoreMe;

}
