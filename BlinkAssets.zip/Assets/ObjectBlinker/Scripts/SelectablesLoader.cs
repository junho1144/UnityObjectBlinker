using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SelectablesLoader : MonoBehaviour
{
    [SerializeField] Toggle blinkOnOffToggle;

    private void Start()
    {
        // check
        if (BlinkManager.Instance.FilterOn)
            Debug.Log("yee");
        else
            Debug.Log("yeeee");

        // turn on/off
        BlinkManager.Instance.FilterOn = true;
        BlinkManager.Instance.FilterOn = false;

        // add to toggle
        blinkOnOffToggle?.onValueChanged.AddListener(
            v => BlinkManager.Instance.FilterOn = v);
    }
}
